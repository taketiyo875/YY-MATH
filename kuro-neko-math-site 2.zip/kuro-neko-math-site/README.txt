くろねこ問題室 — 数学プリントサイト

使い方
1. ZIPを解凍する
2. フォルダ内の index.html を開く
3. 公開する場合は、フォルダ内のファイルをまとめて静的サイト対応サービスにアップロードする

フォルダ構成
- index.html
- assets/kuro-neko-avatar.jpg
- worksheets/ （アップロードされたPDF 6種類）

注意
PDFへのリンクは相対パスです。index.html だけを単独で移動すると、PDFが開けなくなります。
